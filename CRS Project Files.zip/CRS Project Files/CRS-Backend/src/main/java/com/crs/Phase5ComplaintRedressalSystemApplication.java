package com.crs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class Phase5ComplaintRedressalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase5ComplaintRedressalSystemApplication.class, args);
	}
	

}
