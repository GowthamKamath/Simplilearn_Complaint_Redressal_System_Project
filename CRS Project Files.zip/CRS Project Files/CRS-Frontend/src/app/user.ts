export class User {
    userId!: number;
    roleName!: string;
    username!: string;
    password!: string;
    firstName!: string;
    lastName!: string;
    pinCode!: number;
    email!: string;
    phone!: string;
}